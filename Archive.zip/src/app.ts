import express, { Request, Response, Application } from "express";
import rsvpRoutes from "./routes/rsvpRoutes";
import "dotenv/config";

const app: Application = express();

// Middleware to parse incoming JSON requests
app.use(express.json());

// Register Routes
app.use("/api/rsvp", rsvpRoutes);

export default app;
