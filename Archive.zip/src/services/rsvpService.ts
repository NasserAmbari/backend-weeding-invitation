import { RsvpModel, Rsvp } from "../models/rsvpModel";

export class RsvpService {
  static async createRsvp(data: Rsvp) {
    // Basic validation
    if (!data.fullname || !data.message || !data.attendance) {
      throw new Error(
        "All fields (fullname, message, attendance) are required.",
      );
    }

    const validAttendances = ["Hadir", "Tidak Hadir", "Tentative"];
    if (!validAttendances.includes(data.attendance)) {
      throw new Error(
        "Invalid attendance value. Must be 'Hadir', 'Tidak Hadir', or 'Tentative'.",
      );
    }

    const id = await RsvpModel.create(data);
    return { id, ...data };
  }

  static async getAllRsvps() {
    return await RsvpModel.findAll();
  }
}
