import { Router } from "express";
import { RsvpController } from "../controllers/rsvpController";

const router = Router();

router.post("/", RsvpController.create);
router.get("/", RsvpController.getAll);

export default router;
